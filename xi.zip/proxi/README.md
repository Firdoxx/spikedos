# Proxy scraper
Simple and powerful Proxy scraper

## Features
- Regex pattern that scrap proxies from any site!
- Scraping from x75 websites ( You can add more ) 
- Very scraping ( Asynchronous )

### install requirements
```
pip install -r requirements.txt
```
